package com.mlmwizard.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mlmwizard.R
import com.mlmwizard.adapter.FaqAdapter
import com.mlmwizard.interfaces.ClickEventOnRecyclerItem
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.fragment_faq.*
import kotlinx.android.synthetic.main.fragment_faq.view.*

class FaqFragment : Fragment(),ClickEventOnRecyclerItem {
    val itemList: ArrayList<String> = ArrayList();
    companion object {
        fun newInstance(): FaqFragment {
            return FaqFragment()
        }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val rootView = inflater.inflate(R.layout.fragment_faq, container, false)
        if(activity!=null){
            rootView.rvFaq.layoutManager= LinearLayoutManager(activity)
            rootView.rvFaq.adapter = FaqAdapter(this,itemList, activity)
        }
        return rootView
    }

    override fun clickOnItem(position:Int) {
        super<ClickEventOnRecyclerItem>.clickOnItem(position)
        CommonUtils.setSnackBar(rvFaq,"Clicked Positions "+position)
    }

}