package com.mlmwizard.fragment

/**
 * Created by milkway on 6/25/2018.
 */
import android.os.Bundle
import android.support.v4.app.Fragment
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mlmwizard.R
import com.mlmwizard.utils.CommonUtils
import com.mlmwizard.web_services.RetrofitExecuter
import com.mlmwizard.web_services.request_model.ServerRequest
import com.mlmwizard.web_services.response_model.ServerResponse
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.fragment_home.*
import retrofit2.Call
import retrofit2.Callback

//1
class HomeFragment : Fragment() {
    var vi:View?=null
    //2
    companion object {
        fun newInstance(): HomeFragment {
            return HomeFragment()
        }
    }
    //3
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        vi=inflater?.inflate(R.layout.fragment_home, container, false)
        callWebService()
        return vi
    }


    fun callWebService(){
        val request:ServerRequest=ServerRequest();
        request.email="peter@klaven"
        request.password="cityslicka"
        val apiService = RetrofitExecuter().getApiInterface()
        val call = apiService.callLoginWebservice()
        CommonUtils.showProgressDialog(context)
        Log.d("REQUEST", call.toString() + "")
        call.enqueue(object : Callback<ServerResponse> {
            override fun onResponse(call: Call<ServerResponse>, response: retrofit2.Response<ServerResponse>?) {
                CommonUtils.disMissProgressDialog(context)
                if (response != null) {
                    Log.d("id", "" + response.body()?.data?.id)
                    Log.d("Name", "" + response.body()?.data?.name)
                    Log.d("Color", "" + response.body()?.data?.color)
                    tvHomeDetails.text="User ID="+response.body()?.data?.id+"\n"+
                                   "User Name="+response.body()?.data?.name+"\n"+
                                   "User Favourite Color="+response.body()?.data?.color
                }
            }
            override fun onFailure(call: Call<ServerResponse>, t: Throwable) {
                CommonUtils.disMissProgressDialog(context)
            }
        })
    }

}