package com.mlmwizard.utils

import android.app.ProgressDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.preference.PreferenceManager
import android.support.design.widget.Snackbar
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.app.FragmentManager
import android.text.format.DateFormat
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.mlmwizard.R
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

@Suppress("DEPRECATION")
/**
 * Created by milkway on 6/22/2018.
 */
class CommonUtils{
    companion object{
        ///*********** This function is use for Email Validation **********
        private var dialogProgress: ProgressDialog? = null
        fun isValidEmail(target: CharSequence?): Boolean {
            return target != null && Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }

        //************ This function is use to open an fragment ***********
        fun setFragment(fragment: Fragment, removeStack: Boolean, activity: FragmentActivity, mContainer: Int) {
            // currentFragment = fragment
            val fragmentManager = activity.supportFragmentManager
            val ftTransaction = fragmentManager.beginTransaction()
            if (removeStack) {
                fragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
                ftTransaction.replace(mContainer, fragment)
                // ftTransaction.addToBackStack(null);
            } else {
                ftTransaction.replace(mContainer, fragment)
                ftTransaction.addToBackStack(null)
                //ftTransaction.addToBackStack(null);
            }
            ftTransaction.commit()
        }

        //*************** This function is used for SnackBar Information *********************

        fun setSnackBar(view: View,textInformation: String){
            val snackbar = Snackbar.make(view, textInformation, Snackbar.LENGTH_INDEFINITE
            )
            // Get the snack bar root view
            val snack_root_view = snackbar.view
            // Get the snack bar text view
            val snack_text_view = snack_root_view.findViewById<TextView>(android.support.design.R.id.snackbar_text)
            // Get the snack bar action view
            val snack_action_view = snack_root_view.findViewById<Button>(android.support.design.R.id.snackbar_action)
            // Change the snack bar root view background color
            snack_root_view.setBackgroundColor(Color.parseColor("#FFCFBEB4"))
            // Change the snack bar text view text color
            snack_text_view.setTextColor(Color.RED)
            // Change snack bar text view text style
            snack_text_view.setTypeface(Typeface.MONOSPACE, Typeface.BOLD_ITALIC)
            // Change the snack bar action button text color
            snack_action_view.setTextColor(Color.YELLOW)
            // Set an action for snack bar
            snackbar.setAction("Ok",{
                // Hide the snack bar
                snackbar.dismiss()
            })
            // Finally, display the snack bar
            snackbar.show()
        }

        //***************  This function is used to save string data in preferences**************

        fun savePreferencesString(context: Context, key: String, value: String) {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            val editor = sharedPreferences.edit()
            editor.putString(key, value)

            editor.apply()
        }

        //***************  This function is used to Get string data in preferences**************
        fun getPreferencesString(context: Context, key: String): String {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            return sharedPreferences.getString(key, "")
        }


        //***************  This function is used to save Boolean data in preferences**************
        fun savePreferencesBoolean(context: Context, key: String, value: Boolean) {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            val editor = sharedPreferences.edit()
            editor.putBoolean(key, value)
            editor.apply()
        }

        //***************  This function is used to Get Boolean data in preferences**************

        fun getPreferencesBoolean(context: Context, key: String): Boolean {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            return sharedPreferences.getBoolean(key, false)
        }

        //***************  This function is used to save Int data in preferences**************
        fun saveIntPreferences(context: Context, key: String, value: Int) {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            val editor = sharedPreferences.edit()
            editor.putInt(key, value)
            editor.apply()
        }

        //***************  This function is used to Get Int data in preferences**************
        fun getIntPreferences(context: Context, key: String): Int {
            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
            return sharedPreferences.getInt(key, 0)
        }


        fun getDate(context: Context, timestamp_in_string: String): String {
            val dv = java.lang.Long.valueOf(timestamp_in_string)// its need to be in milisecond
            val df = Date(dv)
            //  String vv = new SimpleDateFormat("yyyy-MM-dd").format(df);
            /*
             String[] bits = str.split("-");
     String mnth = bits[0];

    */
            return SimpleDateFormat("dd/MM/yyyy").format(df)
        }

        fun getTime(timestamp_in_string: String): String {
            val dv = java.lang.Long.valueOf(timestamp_in_string)!! * 1000// its need to be in milisecond
            val cal = Calendar.getInstance(Locale.ENGLISH)
            cal.timeInMillis = dv
            return DateFormat.format("hh:mm:ss", cal).toString()
        }

        fun getTimeFormat(timestamp_in_string: String): String {
            val dv = java.lang.Long.valueOf(timestamp_in_string)!! * 1000// its need to be in milisecond
            val cal = Calendar.getInstance(Locale.ENGLISH)
            cal.timeInMillis = dv
            return DateFormat.format("hh:mm aa", cal).toString()
        }

        fun calculateDistanceInMiles(distance: Double): String {
            val df = DecimalFormat("#.###")
            df.roundingMode = RoundingMode.CEILING
            return df.format(distance)
        }

        fun showProgressDialog(context: Context?) {
            if (context != null) {

                if (dialogProgress == null) {
                    dialogProgress = ProgressDialog(context)
                    dialogProgress!!.getWindow()!!.setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    //   dialogProgress.setIndeterminateDrawable(context.getResources().getDrawable(R.drawable.my_progress_indeterminate));
                    //   dialogProgress.setMessage("Loading...");
                    dialogProgress!!.setMessage(context.getString(R.string.loading).trim { it <= ' ' })
                    if (!dialogProgress!!.isShowing()) {
                        try {
                            dialogProgress!!.show()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    dialogProgress!!.setCancelable(false)
                }
            }
        }

        fun disMissProgressDialog(context: Context?) {
            try {
                if (dialogProgress != null) {
                    dialogProgress!!.dismiss()
                    dialogProgress = null
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }
}