package com.mlmwizard.utils

/**
 * Created by milkway on 6/25/2018.
 */
class AppConstants{
    companion object{
        var USER_IMAGE_LOCAL="user_image_local"
        var FROM_CAMERA="from_camera"
        var FROM_GALLERY="from_gallery"
        var TEMP="temp"
        val JPG_EXT = ".jpg"
    }
}