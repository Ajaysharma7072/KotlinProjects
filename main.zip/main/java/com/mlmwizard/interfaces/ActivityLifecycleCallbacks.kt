package com.mlmwizard.interfaces

import android.os.Bundle
import android.app.Activity

/**
 * Created by milkway on 6/27/2018.
 */
interface ActivityLifecycleCallbacks {
    fun onActivityStopped(activity: Activity)
    fun onActivityStarted(activity: Activity)
    fun onActivitySaveInstanceState(activity: Activity, outState: Bundle)
    fun onActivityResumed(activity: Activity)
    fun onActivityPaused(activity: Activity)
    fun onActivityDestroyed(activity: Activity)
    fun onActivityCreated(activity: Activity, savedInstanceState: Bundle)
}