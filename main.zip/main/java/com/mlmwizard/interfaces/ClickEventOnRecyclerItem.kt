package com.mlmwizard.interfaces

/**
 * Created by milkway on 6/27/2018.
 */
interface ClickEventOnRecyclerItem {
    fun clickOnItem(position: Int){
    }
}