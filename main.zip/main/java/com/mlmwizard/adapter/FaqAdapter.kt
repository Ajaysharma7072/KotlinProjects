package com.mlmwizard.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mlmwizard.R
import com.mlmwizard.interfaces.ClickEventOnRecyclerItem
import kotlinx.android.synthetic.main.row_faq.view.*

/**
 * Created by milkway on 6/25/2018.
 */
class FaqAdapter(val clickListeners: ClickEventOnRecyclerItem, val items : ArrayList<String>, val  context: Context?) : RecyclerView.Adapter<FaqAdapter.ViewHolder>() {

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
       holder.llRoot.setOnClickListener(View.OnClickListener {
           clickListeners.clickOnItem(position)
       })
    }
    override fun getItemCount(): Int {
        return 25
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.row_faq, parent, false)
        return ViewHolder(v);
    }
    class ViewHolder(v: View):RecyclerView.ViewHolder(v){
        val tvFaqDetails=v.tvFaqDetails
        val llRoot=v.llRoot;
    }
}