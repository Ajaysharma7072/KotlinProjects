package com.mlmwizard.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.mlmwizard.R
import com.mlmwizard.model.Product
import kotlinx.android.synthetic.main.row_product.view.*

/**
 * Created by milkway on 6/25/2018.
 */
class ProductAdapter(val items : ArrayList<Product>, val  context: Context?) : RecyclerView.Adapter<ProductAdapter.ViewHolder>() {

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvProductname.text=""+position+" "+ items[position].productName.toString()
        holder.tvProductQuentity.text=items[position].quantity.toString()
    }
    override fun getItemCount(): Int {
        return items.size
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent?.context).inflate(R.layout.row_product, parent, false)
        return ViewHolder(v);
    }

    class ViewHolder(v: View):RecyclerView.ViewHolder(v){
        val tvProductname=v.tvProductname
        val tvProductQuentity=v.tvProductQuentity
    }
}