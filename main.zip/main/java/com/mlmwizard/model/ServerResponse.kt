package com.mlmwizard.model

/**
 * Created by milkway on 6/26/2018.
 */
class ServerResponse  {
}