package com.mlmwizard.model

/**
 * Created by milkway on 6/27/2018.
 */
class Product {
    var id: Int = 0
    var productName: String? = null
    var quantity: Int = 0

}