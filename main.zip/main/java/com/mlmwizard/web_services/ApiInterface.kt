package com.mlmwizard.web_services

import com.mlmwizard.web_services.request_model.ServerRequest
import com.mlmwizard.web_services.response_model.ServerResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/**
 * Created by milkway on 6/26/2018.
 */
interface ApiInterface {

    @GET("user/2")
    fun callLoginWebservice(): Call<ServerResponse>

}