package com.mlmwizard.web_services.request_model

/**
 * Created by milkway on 6/26/2018.
 */
class ServerRequest  {
    var email:String?=null
    var password:String?=null
}
