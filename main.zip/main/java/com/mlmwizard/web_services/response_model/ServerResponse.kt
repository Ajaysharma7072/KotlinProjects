package com.mlmwizard.web_services.response_model

/**
 * Created by milkway on 6/26/2018.
 */
class ServerResponse  {
   // var token:String?=null
    var data:Data=Data()
    class Data{
        var id:Int?=null
        var first_name:String?=null
        var name:String?=null
        var last_name:String?=null
        var avatar:String?=null
        var year:Int?=null
        var color:String?=null
        var pantone_value:String?=null
    }
}