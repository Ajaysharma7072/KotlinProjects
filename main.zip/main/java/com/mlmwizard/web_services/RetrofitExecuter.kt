package com.mlmwizard.web_services

import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Created by milkway on 6/26/2018.
 */
 class RetrofitExecuter{
    // Staging URL....
   // var BASE_URL = "http://ec2-52-1-133-240.compute-1.amazonaws.com/PROJECTS/Zenith/api/"
    var BASE_URL = "https://reqres.in/api/"

    fun getApiInterface(): ApiInterface {
        val interceptor = HttpLoggingInterceptor()
        interceptor.level = HttpLoggingInterceptor.Level.BODY

        val credentials = "zenithadmin" + ":" + "zenithadmin1234"
       // val basic = "Basic " + Base64.encodeToString(credentials.toByteArray(), Base64.NO_WRAP)

        val okHttpClient = OkHttpClient()
        val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient.newBuilder().connectTimeout((2 * 60 * 1000).toLong(), TimeUnit.SECONDS).readTimeout((2 * 60 * 1000).toLong(), TimeUnit.SECONDS).writeTimeout((2 * 60 * 1000).toLong(), TimeUnit.SECONDS)
                        .addInterceptor { chain ->
                            val original = chain.request()
                            val requestBuilder = original.newBuilder()
                                    .header("Authorization", "Content-Type:application/json")
                                  //  .header("Authorization", basic)
                                    .method(original.method(), original.body())

                            val request = requestBuilder.build()
                            chain.proceed(request)
                        }
                        .addInterceptor(interceptor)
                        /* .connectTimeout(100, TimeUnit.SECONDS)
                        .readTimeout(120, TimeUnit.SECONDS)*/
                        .build()).build()
        return retrofit.create<ApiInterface>(ApiInterface::class.java)
    }
}