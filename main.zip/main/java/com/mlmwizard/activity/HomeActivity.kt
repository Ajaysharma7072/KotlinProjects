package com.mlmwizard.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.view.GravityCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.Gravity
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import com.mlmwizard.R
import com.mlmwizard.fragment.AboutUsFragment
import com.mlmwizard.fragment.FaqFragment
import com.mlmwizard.fragment.HomeFragment
import com.mlmwizard.utils.CommonUtils
import com.mlmwizard.web_services.RetrofitExecuter
import com.mlmwizard.web_services.response_model.ServerResponse
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.toolbar.view.*
import retrofit2.Call
import retrofit2.Callback

class HomeActivity : AppCompatActivity(), View.OnClickListener {
    var actionBarDrawerToggle: ActionBarDrawerToggle? = null
    // var fragment: Fragment? = null
    var fragment: Fragment = Fragment()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        setListeners()
        setMenuDrawer()
        toolbar.tvToolbarTitle.text="Home"
        fragment = HomeFragment()
        CommonUtils.setFragment(fragment, true, this@HomeActivity, R.id.flHome)
    }

    private fun setMenuDrawer() {
        actionBarDrawerToggle = object : ActionBarDrawerToggle(this, drawerLayout, R.string.app_name, R.string.app_name) {
            override fun onDrawerClosed(drawerView: View) {
            }
            override fun onDrawerOpened(drawerView: View) {
                //CommonUtils.hideKeyboard(this@HomeActivity)
            }
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {
                super.onDrawerSlide(drawerView, slideOffset)
                llHome.setTranslationX(slideOffset * drawerView!!.width)
                llDrawerLeft.bringChildToFront(drawerView)
                llDrawerLeft.requestLayout() }

            @SuppressLint("RtlHardcoded")
            override fun onOptionsItemSelected(item: MenuItem?): Boolean {
                drawerLayout.closeDrawer(Gravity.RIGHT)
                return super.onOptionsItemSelected(item)
            }
        }
        drawerLayout.addDrawerListener(actionBarDrawerToggle as ActionBarDrawerToggle)
        (actionBarDrawerToggle as ActionBarDrawerToggle).syncState()
        svHome.fullScroll(ScrollView.FOCUS_UP)
        svHome.setFocusableInTouchMode(true)
        svHome.setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS)
    }

    private fun setListeners() {
        llDrawerHome.setOnClickListener(this)
        llFaq.setOnClickListener(this)
        llAboutUs.setOnClickListener(this)
        ivUser.setOnClickListener(this)
        llLogout.setOnClickListener(this)
        toolbar.ivToolbarLeft.setOnClickListener(this)
        toolbar.tvToolbarTitle.text="Home"
        toolbar.ivToolbarLeft.setImageResource(R.mipmap.n_menu)
    }

    override fun onClick(v: View?) {
        when(v?.id){

            R.id.ivToolbarLeft->{
                drawerLayout.openDrawer(Gravity.LEFT)
            }


            R.id.ivUser->{
                val intentEditProfile= Intent(this,EditProfileActivity::class.java)
                startActivity(intentEditProfile)
            }

            R.id.llDrawerHome->{
                toolbar.tvToolbarTitle.text="Home"
                fragment = HomeFragment()
                CommonUtils.setFragment(fragment, true, this@HomeActivity, R.id.flHome)
                // CommonUtils.setSnackBar(llFaq,"Work in progress for Home")
                drawerLayout.closeDrawers()
            }
            R.id.llFaq->{
                toolbar.tvToolbarTitle.text="FAQ"
                fragment = FaqFragment()
                CommonUtils.setFragment(fragment, true, this@HomeActivity, R.id.flHome)
                CommonUtils.setSnackBar(llFaq,"Work in progress for FAQ")
                drawerLayout.closeDrawers()
            }
            R.id.llAboutUs->{
                toolbar.tvToolbarTitle.text="About Us"
/*                fragment = AboutUsFragment()
                CommonUtils.setFragment(fragment , true, this@HomeActivity, R.id.flHome)
                CommonUtils.setSnackBar(llFaq,"Work in progress for About Us")*/

                val intent=Intent(this,HelpTutorialsActivity::class.java)
                startActivity(intent)

                drawerLayout.closeDrawers()
            }
            R.id.llLogout->{
                android.app.AlertDialog.Builder(this).setTitle("Logout")
                        .setMessage("Are you sure you want to logout?")
                        .setPositiveButton("Yes") { dialog, which ->
                            //  moveTaskToBack(true);
                            finish()
                        }.setNegativeButton("No", null).show()
                // CommonUtils.setSnackBar(llFaq,"Work in progress for Logout")
            }
        }
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawers()
        } else if (supportFragmentManager.findFragmentById(R.id.flHome) != null) {
            val f = supportFragmentManager.findFragmentById(R.id.flHome)
            if (f is HomeFragment) {
                android.app.AlertDialog.Builder(this).setTitle("Exit")
                        .setMessage("Do you want to exit from App?")
                        .setPositiveButton("Yes") { dialog, which -> moveTaskToBack(true) }.setNegativeButton("No", null).show()
            } else {
                toolbar.tvToolbarTitle.text="Home"
                fragment = HomeFragment()
                CommonUtils.setFragment(fragment as HomeFragment, true, this as FragmentActivity, R.id.flHome)
            }
        }
    }

}