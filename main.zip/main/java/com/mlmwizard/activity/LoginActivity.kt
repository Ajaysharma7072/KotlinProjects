package com.mlmwizard.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.mlmwizard.R
import com.mlmwizard.receiver.MyReceiver
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity(), View.OnClickListener, TextWatcher {

    val unReg:MyReceiver?= MyReceiver()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        setClickListeners()
        unRegisterReceiver()
    }
    //**** This method is calling to set click listeners event ******
    private fun setClickListeners() {
        tvLogin.setOnClickListener(this)
        tvForgotPassword.setOnClickListener(this)
        tvSignUp.setOnClickListener(this)
        etEmail.addTextChangedListener(this)
        etPassword.addTextChangedListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tvLogin -> {
                if(checkValidation()){
                    val intentHome=Intent(this,HomeActivity::class.java)
                    startActivity(intentHome)
                }
            }
            R.id.tvForgotPassword ->{
                val intent=Intent(this,ForgotPasswordActivity::class.java)
                startActivity(intent)
            }
            R.id.tvSignUp ->{
                val intent=Intent(this,SignUpActivity::class.java)
                startActivity(intent)
            }
        }
    }

    private fun checkValidation(): Boolean {
        if(etEmail.text.toString().trim().equals("")){
            tvErrorEmail.visibility=View.VISIBLE;
            etEmail.requestFocus()
            return false
        }else if(!CommonUtils.isValidEmail(etEmail.text.toString())){
            tvErrorEmail.visibility=View.VISIBLE
            tvErrorEmail.text=getText(R.string.ple_enter_valid_email)
            return false;
        } else if(etPassword.text.toString().trim().equals("")){
            tvErrorPassword.visibility=View.VISIBLE;
            etPassword.requestFocus()
            return false
        }else if(etPassword.text.toString().trim().length<8){
            tvErrorPassword.visibility=View.VISIBLE
            tvErrorPassword.text=getText(R.string.password_length_should_be_8_character)
        }
        return true
    }

    override fun afterTextChanged(p0: Editable?) {
    }
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        tvErrorPassword.visibility=View.GONE
        tvErrorEmail.visibility=View.GONE
    }
    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }

    fun unRegisterReceiver(){
        if (unReg != null) {
            if(unReg.debugUnregister)
                this.unregisterReceiver(unReg)
        };
    }
}