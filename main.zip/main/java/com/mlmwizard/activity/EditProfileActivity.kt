package com.mlmwizard.activity

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Base64
import android.view.*
import android.widget.TextView
import com.mlmwizard.R
import com.mlmwizard.image_manager.SelectPictureUtils
import com.mlmwizard.image_manager.TakePictureUtils
import com.mlmwizard.image_manager.TakePictureUtils.TAKE_PICTURE
import com.mlmwizard.image_utils.CropImage
import com.mlmwizard.utils.AppConstants
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_edit_profile.*
import kotlinx.android.synthetic.main.toolbar.view.*
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

class EditProfileActivity : AppCompatActivity(), View.OnClickListener {
    var REQUEST_CODE_ASK_PERMISSIONS=123 ;
    var image_profile=""
    val selectPictureUtils=SelectPictureUtils(this);

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)
        setOnClickListeners()
    }
    private fun setOnClickListeners() {
        ivProfile.setOnClickListener(this)
        toolbar.ivToolbarLeft.setOnClickListener(this)
        tvEdit.setOnClickListener(this)
        toolbar.tvToolbarTitle.text="Profile"
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.ivProfile->{
                marshmallow()
            }
            R.id.ivToolbarLeft->{
                finish()
            }
            R.id.tvEdit->{
                CommonUtils.setSnackBar(tvEdit,"Work in progress for edit profile..")
            }
        }
    }

    private fun marshmallow() {
        if (Build.VERSION.SDK_INT < 23) {
            addPhotoDialog()
        } else {
            var hasPermissionCounter = 0
            val permission = arrayOf(Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE)
            for (aPermission in permission) {
                if (this.checkSelfPermission(aPermission) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(aPermission), REQUEST_CODE_ASK_PERMISSIONS)
                } else {
                    hasPermissionCounter++
                }
            }
            if (hasPermissionCounter == 2) {
                addPhotoDialog()
            }
        }
    }

    protected fun addPhotoDialog() {
        val inflater = LayoutInflater.from(this)
        val mDialog = Dialog(this, android.R.style.Theme_Translucent_NoTitleBar)
        if (mDialog.window != null)
            mDialog.window!!.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        mDialog.window!!.setGravity(Gravity.BOTTOM)
        val lp = mDialog.window!!.attributes
        lp.dimAmount = 0.75f
        mDialog.window!!.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        mDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        mDialog.window
        val dialogLayout = inflater.inflate(R.layout.popup_profilepic, null)

        val tvCamera: TextView = dialogLayout.findViewById(R.id.tvCamera)
        val tvGallery: TextView = dialogLayout.findViewById(R.id.tvGallery)
        val tvCancel: TextView = dialogLayout.findViewById(R.id.tvCancel)
        mDialog.setContentView(dialogLayout)
        mDialog.show()

        tvCamera.setOnClickListener(View.OnClickListener {
            mDialog.dismiss()
            selectPictureUtils.takePictureFromCamera()
        })

        tvGallery.setOnClickListener(View.OnClickListener {
            mDialog.dismiss()
            selectPictureUtils.openGallery()
        })

        tvCancel.setOnClickListener(View.OnClickListener {
            mDialog.dismiss()
        })
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, intent: Intent?) {
        super.onActivityResult(requestCode, resultCode, intent)

        if (requestCode == TakePictureUtils.PICK_GALLERY) {
            if (resultCode == Activity.RESULT_OK) {
                try {
                    val inputStream = this.getContentResolver().openInputStream(intent!!.data!!)
                    val fileOutputStream = FileOutputStream(File(this.getExternalFilesDir(AppConstants.TEMP), selectPictureUtils.galleryImagePath + AppConstants.JPG_EXT))
                    TakePictureUtils.copyStream(inputStream, fileOutputStream)
                    fileOutputStream.close()
                    if (inputStream != null) {
                        inputStream!!.close()
                    }
                } catch (ee: Exception) {
                    ee.printStackTrace()
                }

                startCropImage(this as Activity, selectPictureUtils.getGalleryImagePath(intent), AppConstants.FROM_GALLERY)
            }
        } else if (requestCode == TAKE_PICTURE) {
            startCropImage(this as Activity, selectPictureUtils.imagePath, AppConstants.FROM_CAMERA)
        } else if (requestCode == TakePictureUtils.CROP_FROM_CAMERA) {
            if (resultCode == Activity.RESULT_OK) {
                var path: String? = null
                if (intent != null) {
                    path = intent.getStringExtra(CropImage.IMAGE_PATH)
                }
                if (path == null) {
                    return
                }

                val bm = BitmapFactory.decodeFile(path)
                val baos = ByteArrayOutputStream()
                bm!!.compress(Bitmap.CompressFormat.JPEG, 100, baos) //bm is the bitmap object
                val byteArrayImage = baos.toByteArray()
                image_profile = Base64.encodeToString(byteArrayImage, Base64.DEFAULT)
                //   Picasso.with(mContext).load(new File(path)).placeholder(R.mipmap.edit_profile).transform(new CircleTransformation()).into(binding.ivProfile);
                CommonUtils.savePreferencesString(this, AppConstants.USER_IMAGE_LOCAL, path)
                if (bm != null) {
                    ivProfile.setImageBitmap(bm)
                }

            }
        }
    }


    fun startCropImage(context: Activity, fileName: String, takeBy: String) {
        val intent = Intent(context, CropImage::class.java)
        if (Build.VERSION.SDK_INT > 23) {
            if (takeBy.equals(AppConstants.FROM_CAMERA, ignoreCase = true)) {
                intent.putExtra(CropImage.IMAGE_PATH, File(fileName).path)
            } else {
                intent.putExtra(CropImage.IMAGE_PATH, File(context.getExternalFilesDir(AppConstants.TEMP), fileName).path)
            }
        } else {
            intent.putExtra(CropImage.IMAGE_PATH, File(context.getExternalFilesDir(AppConstants.TEMP), fileName).path)
        }
        intent.putExtra(CropImage.SCALE, true)
        intent.putExtra(CropImage.ASPECT_X, 0)
        intent.putExtra(CropImage.ASPECT_Y, 1)
        intent.putExtra(CropImage.OUTPUT_X, 200)
        intent.putExtra(CropImage.OUTPUT_Y, 200)
        startActivityForResult(intent, TakePictureUtils.CROP_FROM_CAMERA)
    }

}