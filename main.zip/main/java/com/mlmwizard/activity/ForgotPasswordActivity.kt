package com.mlmwizard.activity

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.mlmwizard.R
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.toolbar.view.*

class ForgotPasswordActivity : AppCompatActivity(), View.OnClickListener, TextWatcher {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        setClickListeners()
    }

    //**** This method is calling to set click listeners event ******
    private fun setClickListeners() {
        tvSubmit.setOnClickListener(this)
        tvSignUp.setOnClickListener(this)
        toolbar.ivToolbarLeft.setOnClickListener(this)
        toolbar.tvToolbarTitle.text=getString(R.string.forgot_password)
        etEmail.addTextChangedListener(this)
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tvSubmit ->{
                if(checkValidation()){
                    Toast.makeText(baseContext,"Work in progress",Toast.LENGTH_SHORT).show()
                }
            }
            R.id.tvSignUp ->{
                val intent=Intent(this,SignUpActivity::class.java)
                startActivity(intent)
            }
            R.id.ivToolbarLeft ->{
                finish()
            }
        }
    }

    private fun checkValidation(): Boolean {
        if(etEmail.text.toString().trim().equals("")){
            tvErrorEmail.visibility=View.VISIBLE;
            return false
        }else if(!CommonUtils.isValidEmail(etEmail.text.toString().trim())){
            tvErrorEmail.visibility=View.VISIBLE
            tvErrorEmail.text=getText(R.string.ple_enter_valid_email)
            return false
        }
        return true
    }

    override fun afterTextChanged(p0: Editable?) {
    }
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }
    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        tvErrorEmail.visibility=View.GONE
    }


    class someTask() : AsyncTask<Void, Void, String>() {
        override fun doInBackground(vararg params: Void?): String? {
            // ...
            return null
        }
        override fun onPreExecute() {
            super.onPreExecute()
            // ...
        }
        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            // ...
        }
    }


}