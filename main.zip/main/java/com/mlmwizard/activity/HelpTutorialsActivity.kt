package com.mlmwizard.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.mlmwizard.R
import com.mlmwizard.adapter.ViewPagerAdapter
import com.mlmwizard.fragment.HelpTutorialFragment
import kotlinx.android.synthetic.main.activity_help_tutorial.*

class HelpTutorialsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help_tutorial)

        val viewPagerAdapter = ViewPagerAdapter(supportFragmentManager)
        val helpFragment = HelpTutorialFragment()
        val helpFragment1 = HelpTutorialFragment()
        val helpFragment2 = HelpTutorialFragment()

        viewPagerAdapter.addFrag(helpFragment, "help1")
        viewPagerAdapter.addFrag(helpFragment1, "help2")
        viewPagerAdapter.addFrag(helpFragment2, "help3")
        viewPager.setAdapter(viewPagerAdapter)
        viewPagerIndicator.setupWithViewPager(viewPager)
    }

    fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {
    }
    fun onPageSelected(position: Int) {
    }
    fun onPageScrollStateChanged(state: Int) {
    }


}
