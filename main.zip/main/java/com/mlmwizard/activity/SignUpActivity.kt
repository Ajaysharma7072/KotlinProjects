package com.mlmwizard.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import com.mlmwizard.R
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_signup.*
import kotlinx.android.synthetic.main.toolbar.*

class SignUpActivity : AppCompatActivity(), View.OnClickListener, TextWatcher {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)
        setClickListeners()
    }
    //**** This method is calling to set click listeners event ******
    private fun setClickListeners() {
        tvSignUp.setOnClickListener(this)
        tvTermsAndConditions.setOnClickListener(this)
        ivToolbarLeft.setOnClickListener(this)
        etName.addTextChangedListener(this)
        etEmail.addTextChangedListener(this)
        etMobile.addTextChangedListener(this)
        etPassword.addTextChangedListener(this)
        etConPassword.addTextChangedListener(this)
    }
    override fun onClick(p0: View?) {
        when(p0?.id){
            R.id.tvSignUp->{
                if(checkValidation()){
                    Toast.makeText(baseContext,"Work in progress..",Toast.LENGTH_SHORT).show()
                }
            }
            R.id.ivToolbarLeft->{
                finish()
            }
            R.id.tvTermsAndConditions->{
            }
        }
    }

    private fun checkValidation(): Boolean {
        if(etName.text.toString().trim().equals("")){
            tvErrorName.visibility=View.VISIBLE
            etName.requestFocus()
            return false
        }else if(etEmail.text.toString().trim().equals("")){
            tvErrorEmail.visibility=View.VISIBLE
            etEmail.requestFocus()
            return false
        }else if(!CommonUtils.isValidEmail(etEmail.text.toString().trim())){
            tvErrorEmail.visibility=View.VISIBLE
            tvErrorEmail.text=getString(R.string.ple_enter_valid_email)
            etEmail.requestFocus()
            return false
        }else if(etMobile.text.toString().trim().equals("")){
            tvErrorMobile.visibility=View.VISIBLE
            etMobile.requestFocus()
            return false
        }else if(etMobile.text.toString().trim().length<8){
            tvErrorMobile.visibility=View.VISIBLE
            tvErrorMobile.text=getString(R.string.ple_enter_valid_mobile)
            etMobile.requestFocus()
            return false
        }
        else if(etPassword.text.toString().trim().equals("")){
            tvErrorPassword.visibility=View.VISIBLE
            etPassword.requestFocus()
            return false
        }
        else if(etPassword.text.toString().trim().length<8){
            tvErrorPassword.visibility=View.VISIBLE
            tvErrorPassword.text=getString(R.string.password_length_should_be_8_character)
            etPassword.requestFocus()
            return false
        }
        else if(etConPassword.text.toString().trim().equals("")){
            tvErrorConPassword.visibility=View.VISIBLE
            etConPassword.requestFocus()
            return false
        }
        else if(!etConPassword.text.toString().trim().equals(etPassword.text.toString().trim())){
            tvErrorConPassword.visibility=View.VISIBLE
            tvErrorConPassword.text=getString(R.string.password_not_match)
            etConPassword.requestFocus()
            return false
        }
        else if(!cbTermsConditions.isChecked){
            Toast.makeText(baseContext,getString(R.string.please_select_terms_conditions),Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }


    override fun afterTextChanged(p0: Editable?) {
    }
    override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
    }
    override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
        tvErrorName.visibility=View.GONE
        tvErrorEmail.visibility=View.GONE
        tvErrorMobile.visibility=View.GONE
        tvErrorPassword.visibility=View.GONE
        tvErrorConPassword.visibility=View.GONE
    }

}