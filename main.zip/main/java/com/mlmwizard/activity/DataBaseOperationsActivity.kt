package com.mlmwizard.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.mlmwizard.R
import com.mlmwizard.adapter.ProductAdapter
import com.mlmwizard.database.MyDBHandler
import com.mlmwizard.model.Product
import com.mlmwizard.utils.CommonUtils
import kotlinx.android.synthetic.main.activity_database_operations.*
import java.util.*

class DataBaseOperationsActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_database_operations)
        setOnClickListeners()
    }
    private fun setOnClickListeners() {
        tvAddData.setOnClickListener(this)
        tvDelete.setOnClickListener(this)
        tvFetch.setOnClickListener(this)
    }
    override fun onClick(p0: View?) {
        when(p0?.id){
            R.id.tvAddData->{
                if(doValidation()){
                    newProduct();
                    findAllProduct()
                }
            }

            R.id.tvDelete->{
                if(etProductName.text.toString().trim().equals("")){
                    CommonUtils.setSnackBar(etProductName,"Please enter product name!")
                }else{
                    removeProduct()
                    findAllProduct()
                }
            }
            R.id.tvFetch->{
                findAllProduct()
            }
        }
    }

    private fun doValidation(): Boolean {
        if(etProductName.text.toString().trim().equals("")){
            CommonUtils.setSnackBar(etProductName,"Please enter product name!")
            return false
        }
        else if(etProductQuantity.text.toString().trim().equals("")){
            CommonUtils.setSnackBar(etProductName,"Please enter product quantity!")
            return false
        }
        return true
    }

    fun newProduct() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val quantity = Integer.parseInt(etProductQuantity.text.toString())
        val product = Product()
        product.productName=etProductName.text.toString()
        product.quantity=quantity
        dbHandler.addProduct(product)
        etProductName.setText("")
        etProductQuantity.setText("")
    }

    fun removeProduct() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val result = dbHandler.deleteProduct(etProductName.text.toString())
        if (result) {
            tvResult.setText("Record Deleted!")
            etProductName.setText("")
            etProductQuantity.setText("")
        } else
            tvResult.setText("Record is not found!")
    }

    fun findAllProduct() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val result = dbHandler.findAllProduct()
        result.reverse()
        rvProduct.layoutManager= LinearLayoutManager(baseContext)
        rvProduct.adapter = ProductAdapter(result, baseContext)
    }


}
