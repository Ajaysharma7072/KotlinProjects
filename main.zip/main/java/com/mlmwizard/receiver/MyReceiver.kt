package com.mlmwizard.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.mlmwizard.activity.SplashActivity

/**
 * Created by milkway on 6/28/2018.
 */
class MyReceiver : BroadcastReceiver() {
    override fun onReceive(p0: Context?, p1: Intent?) {
        val intent=Intent(p0,SplashActivity::class.java)
        p0?.startActivity(intent)

    }
}